# Movie Database Website

Demo: https://reels.netlify.app/

## Tools used:

- React
- Webpack
- Axios
- React Router
- React Modal
- Lodash

## Running Project Locally:

- Install dependencies: run `npm install` in the root project
- Run project: `npm run dev`
